import { SkillAssessment } from "@/components/skill-assessment"

export default function AssessmentPage() {
  return <SkillAssessment />
}
