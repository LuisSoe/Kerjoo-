import { LearningModules } from "@/components/learning-modules"

export default function LearningPage() {
  return <LearningModules />
}
